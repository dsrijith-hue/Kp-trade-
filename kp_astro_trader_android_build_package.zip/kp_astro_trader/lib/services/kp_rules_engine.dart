import '../models/kp_snapshot.dart';

/// Transparent, deliberately conservative starter rule set.
/// It does NOT calculate ephemerides or claim predictive validity.
/// Significator houses are supplied by a verified KP calculation provider.
class KpRulesEngine {
  static const Set<int> gainHouses = {2, 6, 10, 11};
  static const Set<int> cautionHouses = {5, 8, 12};

  KpAssessment assess(KpSnapshot snapshot) {
    final sl = _planet(snapshot, snapshot.ascendantSl);
    final ssl = _planet(snapshot, snapshot.ascendantSsl);
    final nl = _planet(snapshot, snapshot.ascendantNl);
    final rl = _planet(snapshot, snapshot.ascendantRl);
    final warnings = <String>[];
    final rationale = <String>[];

    if (sl == null || ssl == null || nl == null || rl == null) {
      return KpAssessment(
        bias: MarketBias.neutral,
        signal: TradeSignal.wait,
        score: 0,
        rationale: ['Required NL/RL/SL/SSL significator data is incomplete.'],
        warnings: ['No trade signal generated. Enter verified KP data before analysis.'],
      );
    }

    // The SL is weighted most heavily; SSL is a confirmation layer.
    final slScore = _houseScore(sl.signifiedHouses);
    final sslScore = _houseScore(ssl.signifiedHouses);
    final nlScore = _houseScore(nl.signifiedHouses);
    final rlScore = _houseScore(rl.signifiedHouses);
    final score = (slScore * 4 + sslScore * 3 + nlScore * 2 + rlScore).clamp(-100, 100);

    rationale.add('SL ${sl.planet}: ${_houseSummary(sl.signifiedHouses)} (highest weight).');
    rationale.add('SSL ${ssl.planet}: ${_houseSummary(ssl.signifiedHouses)} (confirmation weight).');
    rationale.add('NL ${nl.planet}: ${_houseSummary(nl.signifiedHouses)}.');
    rationale.add('RL ${rl.planet}: ${_houseSummary(rl.signifiedHouses)}.');
    warnings.add('This is a configurable traditional-KP interpretation, not a statistically validated market forecast.');
    warnings.add('Ascendant-only analysis is insufficient for a complete KP horary or market judgement.');

    final bias = score >= 20 ? MarketBias.bullish : score <= -20 ? MarketBias.bearish : MarketBias.neutral;
    // A bias is not an execution instruction. Require explicit user confirmation.
    final signal = bias == MarketBias.bullish ? TradeSignal.buy : bias == MarketBias.bearish ? TradeSignal.sell : TradeSignal.wait;
    return KpAssessment(bias: bias, signal: signal, score: score, rationale: rationale, warnings: warnings);
  }

  PlanetaryFactor? _planet(KpSnapshot s, String name) {
    for (final p in s.planets) {
      if (p.planet.toLowerCase() == name.toLowerCase()) return p;
    }
    return null;
  }

  int _houseScore(List<int> houses) {
    final gains = houses.where(gainHouses.contains).length;
    final caution = houses.where(cautionHouses.contains).length;
    return gains - caution;
  }

  String _houseSummary(List<int> houses) => houses.isEmpty ? 'no house data supplied' : 'houses ${houses.toSet().toList()..sort()}' .replaceAll('[', '').replaceAll(']', '');
}
