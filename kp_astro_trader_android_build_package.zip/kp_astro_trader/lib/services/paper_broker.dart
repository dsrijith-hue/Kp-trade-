class PaperPosition {
  PaperPosition({required this.symbol, required this.side, required this.quantity, required this.entryPrice, required this.openedAt}) : id = DateTime.now().microsecondsSinceEpoch.toString();
  final String id;
  final String symbol;
  final String side;
  final int quantity;
  final double entryPrice;
  final DateTime openedAt;
  double? exitPrice;
  DateTime? closedAt;
  bool get isOpen => closedAt == null;
  double get realisedPnl => exitPrice == null ? 0 : (side == 'BUY' ? exitPrice! - entryPrice : entryPrice - exitPrice!) * quantity;
}

class PaperBroker {
  double virtualCapital = 100000;
  final List<PaperPosition> positions = [];

  PaperPosition? open({required String symbol, required String side, required int quantity, required double price}) {
    if (quantity <= 0 || price <= 0 || (side != 'BUY' && side != 'SELL')) return null;
    final requiredMargin = quantity * price;
    if (side == 'BUY' && requiredMargin > virtualCapital) return null;
    final p = PaperPosition(symbol: symbol, side: side, quantity: quantity, entryPrice: price, openedAt: DateTime.now());
    positions.insert(0, p);
    return p;
  }

  bool close(String id, double price) {
    final p = positions.where((x) => x.id == id && x.isOpen).firstOrNull;
    if (p == null || price <= 0) return false;
    p.exitPrice = price;
    p.closedAt = DateTime.now();
    virtualCapital += p.realisedPnl;
    return true;
  }
}
