import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() => runApp(const KpAstroTraderApp());

class KpAstroTraderApp extends StatelessWidget {
  const KpAstroTraderApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'KP Astro Trader',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF5478E8), brightness: Brightness.dark), useMaterial3: true, scaffoldBackgroundColor: const Color(0xFF0B1020)),
    home: const HomeScreen(),
  );
}
