enum MarketBias { bullish, bearish, neutral }
enum TradeSignal { buy, sell, wait, exit }

class PlanetaryFactor {
  const PlanetaryFactor({required this.planet, required this.sign, required this.degree, required this.nakshatraLord, required this.rasiLord, required this.subLord, required this.subSubLord, this.signifiedHouses = const []});
  final String planet;
  final String sign;
  final double degree;
  final String nakshatraLord;
  final String rasiLord;
  final String subLord;
  final String subSubLord;
  final List<int> signifiedHouses;
}

class KpSnapshot {
  const KpSnapshot({required this.timestamp, required this.ascendant, required this.ascendantSign, required this.ascendantDegree, required this.ascendantNl, required this.ascendantRl, required this.ascendantSl, required this.ascendantSsl, required this.planets, required this.dataSource});
  final DateTime timestamp;
  final String ascendant;
  final String ascendantSign;
  final double ascendantDegree;
  final String ascendantNl;
  final String ascendantRl;
  final String ascendantSl;
  final String ascendantSsl;
  final List<PlanetaryFactor> planets;
  final String dataSource;
}

class KpAssessment {
  const KpAssessment({required this.bias, required this.signal, required this.score, required this.rationale, required this.warnings});
  final MarketBias bias;
  final TradeSignal signal;
  /// Rule score, not a probability or a forecast accuracy percentage.
  final int score;
  final List<String> rationale;
  final List<String> warnings;
}
