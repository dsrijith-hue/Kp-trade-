import 'package:flutter/material.dart';
import '../models/kp_snapshot.dart';
import '../services/kp_rules_engine.dart';
import '../services/paper_broker.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _broker = PaperBroker();
  final _engine = KpRulesEngine();
  final _symbol = TextEditingController(text: 'NIFTY');
  final _price = TextEditingController(text: '24000');
  final _qty = TextEditingController(text: '1');
  final _asc = TextEditingController(text: 'Taurus');
  final _nl = TextEditingController(text: 'Moon');
  final _rl = TextEditingController(text: 'Venus');
  final _sl = TextEditingController(text: 'Saturn');
  final _ssl = TextEditingController(text: 'Mercury');
  final _seconds = TextEditingController();
  DateTime _selectedDateTime = DateTime.now();
  final Map<String, TextEditingController> _houses = {for (final p in ['Moon','Venus','Saturn','Mercury']) p: TextEditingController()};
  KpAssessment? _assessment;
  int _tab = 0;

  @override
  void initState() {
    super.initState();
    _seconds.text = _two(_selectedDateTime.second);
  }

  @override
  void dispose() {
    for (final c in [_symbol,_price,_qty,_asc,_nl,_rl,_sl,_ssl,_seconds,..._houses.values]) { c.dispose(); }
    super.dispose();
  }

  List<int> _parseHouses(String value) => value.split(RegExp(r'[, ]+')).where((s) => s.trim().isNotEmpty).map((s) => int.tryParse(s.trim())).whereType<int>().where((n) => n >= 1 && n <= 12).toSet().toList();

  String _two(int value) => value.toString().padLeft(2, '0');

  String get _selectedDateLabel => '${_selectedDateTime.year}-${_two(_selectedDateTime.month)}-${_two(_selectedDateTime.day)}';
  String get _selectedTimeLabel => '${_two(_selectedDateTime.hour)}:${_two(_selectedDateTime.minute)}:${_two(_selectedDateTime.second)}';

  Future<void> _pickDate() async {
    final picked = await showDatePicker(context: context, initialDate: _selectedDateTime, firstDate: DateTime(1900), lastDate: DateTime(2100));
    if (picked != null) setState(() => _selectedDateTime = DateTime(picked.year, picked.month, picked.day, _selectedDateTime.hour, _selectedDateTime.minute, _selectedDateTime.second));
  }

  Future<void> _pickTime() async {
    final picked = await showTimePicker(context: context, initialTime: TimeOfDay.fromDateTime(_selectedDateTime));
    if (picked != null) setState(() { _selectedDateTime = DateTime(_selectedDateTime.year, _selectedDateTime.month, _selectedDateTime.day, picked.hour, picked.minute, int.tryParse(_seconds.text) ?? _selectedDateTime.second); _seconds.text = _two(_selectedDateTime.second); });
  }

  void _setSeconds(String value) {
    final parsed = int.tryParse(value);
    if (parsed == null || parsed < 0 || parsed > 59) return;
    setState(() => _selectedDateTime = DateTime(_selectedDateTime.year, _selectedDateTime.month, _selectedDateTime.day, _selectedDateTime.hour, _selectedDateTime.minute, parsed));
  }

  void _analyse() {
    final names = [_nl.text.trim(),_rl.text.trim(),_sl.text.trim(),_ssl.text.trim()];
    final unique = names.toSet();
    final planets = unique.map((name) => PlanetaryFactor(planet: name, sign: 'Not entered', degree: 0, nakshatraLord: 'Not entered', rasiLord: 'Not entered', subLord: 'Not entered', subSubLord: 'Not entered', signifiedHouses: _parseHouses(_houses[name]?.text ?? ''))).toList();
    final snap = KpSnapshot(timestamp: _selectedDateTime, ascendant: 'Ascendant', ascendantSign: _asc.text, ascendantDegree: 0, ascendantNl: _nl.text, ascendantRl: _rl.text, ascendantSl: _sl.text, ascendantSsl: _ssl.text, planets: planets, dataSource: 'Manual demo input');
    setState(() => _assessment = _engine.assess(snap));
  }

  void _paperTrade(String side) {
    final p = _broker.open(symbol: _symbol.text.trim().toUpperCase(), side: side, quantity: int.tryParse(_qty.text) ?? 0, price: double.tryParse(_price.text) ?? 0);
    setState(() {});
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(p == null ? 'Trade rejected. Check quantity, price and available virtual capital.' : '$side paper position opened for ${p.symbol}.')));
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('KP ASTRO TRADER'), actions: [Padding(padding: const EdgeInsets.only(right: 16), child: Center(child: Chip(label: Text('PAPER MODE', style: TextStyle(color: Colors.amber.shade200, fontSize: 11)))))]),
    body: IndexedStack(index: _tab, children: [_dashboard(), _analysisPage(), _paperPage(), _settingsPage()]),
    bottomNavigationBar: NavigationBar(selectedIndex: _tab, onDestinationSelected: (v) => setState(() => _tab = v), destinations: const [NavigationDestination(icon: Icon(Icons.dashboard_outlined), label: 'Dashboard'), NavigationDestination(icon: Icon(Icons.auto_graph), label: 'KP Analysis'), NavigationDestination(icon: Icon(Icons.receipt_long), label: 'Paper Trades'), NavigationDestination(icon: Icon(Icons.settings_outlined), label: 'Settings')]),
  );

  Widget _dashboard() => ListView(padding: const EdgeInsets.all(16), children: [
    _hero(), const SizedBox(height: 16),
    Row(children: [Expanded(child: _metric('Virtual capital','₹${_broker.virtualCapital.toStringAsFixed(0)}',Icons.account_balance_wallet)), const SizedBox(width: 10), Expanded(child: _metric('Open positions','${_broker.positions.where((p)=>p.isOpen).length}',Icons.show_chart))]),
    const SizedBox(height: 18), const Text('WATCHLIST', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: 1.2)), const SizedBox(height: 8),
    for (final item in [('NIFTY 50','Index • Connect market feed'),('BANK NIFTY','Index • Connect market feed'),('SENSEX','Index • Connect market feed')]) Card(child: ListTile(leading: const CircleAvatar(child: Icon(Icons.trending_up)), title: Text(item.$1), subtitle: Text(item.$2), trailing: const Icon(Icons.chevron_right))),
    const SizedBox(height: 12), _notice('Market data is not connected. Watchlist prices and live signals are intentionally disabled until a trusted feed is configured.'),
  ]);

  Widget _hero() => Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(gradient: const LinearGradient(colors: [Color(0xFF243D7A),Color(0xFF182447)]), borderRadius: BorderRadius.circular(20)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('KP INTRADAY OUTLOOK', style: TextStyle(color: Colors.white70, letterSpacing: 1.1)), const SizedBox(height: 10), Text(_assessment?.signal.name.toUpperCase() ?? 'WAITING FOR ANALYSIS', style: const TextStyle(fontSize: 25, fontWeight: FontWeight.bold)), const SizedBox(height: 6), Text(_assessment == null ? 'Enter verified KP planetary data to evaluate the current setup.' : 'Rule score: ${_assessment!.score} • ${_assessment!.bias.name.toUpperCase()}', style: const TextStyle(color: Colors.white70)), const SizedBox(height: 14), FilledButton.tonal(onPressed: () => setState(()=>_tab=1), child: const Text('Open KP analysis'))]));

  Widget _analysisPage() => ListView(padding: const EdgeInsets.all(16), children: [const Text('KP ANALYSIS INPUT', style: TextStyle(fontSize: 18,fontWeight: FontWeight.bold)), const SizedBox(height: 6), _notice('Demo input only. Enter the verified KP significator planets and their house connections. Automatic astronomical calculations are not yet connected.'), const SizedBox(height: 12), _dateTimeEditor(), const SizedBox(height: 12), _field('Ascendant sign',_asc), _field('Ascendant NL',_nl), _field('Ascendant RL',_rl), _field('Ascendant SL',_sl), _field('Ascendant SSL',_ssl), const SizedBox(height: 8), const Text('HOUSE SIGNIFICATIONS FOR EACH LORD',style: TextStyle(fontWeight: FontWeight.bold)), const SizedBox(height: 4), const Text('Enter house numbers separated by commas, e.g. 2, 6, 10, 11.',style: TextStyle(color: Colors.white60,fontSize: 12)), for (final e in _houses.entries) _field('${e.key} signifies houses',e.value,hint:'e.g. 2, 6, 10, 11'), const SizedBox(height: 12), FilledButton.icon(onPressed: _analyse, icon: const Icon(Icons.analytics_outlined), label: const Text('Analyse KP factors')), if (_assessment != null) ...[_assessmentCard(), for(final w in _assessment!.warnings) _notice(w)] ]);


  Widget _dateTimeEditor() => Card(child: Padding(padding: const EdgeInsets.all(14), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
    const Text('ANALYSIS DATE & TIME', style: TextStyle(fontWeight: FontWeight.bold, letterSpacing: .8)),
    const SizedBox(height: 10),
    Row(children: [Expanded(child: OutlinedButton.icon(onPressed: _pickDate, icon: const Icon(Icons.calendar_month), label: Text(_selectedDateLabel))), const SizedBox(width: 8), Expanded(child: OutlinedButton.icon(onPressed: _pickTime, icon: const Icon(Icons.schedule), label: Text('${_two(_selectedDateTime.hour)}:${_two(_selectedDateTime.minute)}')))]),
    const SizedBox(height: 8),
    Row(children: [SizedBox(width: 112, child: TextField(controller: _seconds, keyboardType: TextInputType.number, maxLength: 2, onChanged: _setSeconds, decoration: const InputDecoration(labelText: 'Seconds (00–59)', counterText: '', border: OutlineInputBorder(), isDense: true))), const SizedBox(width: 12), Expanded(child: Text('Selected timestamp: $_selectedDateLabel $_selectedTimeLabel', style: const TextStyle(color: Colors.white70, fontSize: 12)))]),
    const SizedBox(height: 6),
    Align(alignment: Alignment.centerRight, child: TextButton.icon(onPressed: () => setState(() { _selectedDateTime = DateTime.now(); _seconds.text = _two(_selectedDateTime.second); }), icon: const Icon(Icons.refresh), label: const Text('Use current date & time'))),
    const Text('Seconds are editable independently for precise historical or event-time KP analysis.', style: TextStyle(color: Colors.white54, fontSize: 11)),
  ])));

  Widget _assessmentCard() { final a=_assessment!; final color=a.bias==MarketBias.bullish?Colors.green:a.bias==MarketBias.bearish?Colors.red:Colors.amber; return Card(child: Padding(padding: const EdgeInsets.all(16),child: Column(crossAxisAlignment: CrossAxisAlignment.start,children:[Text('RESULT: ${a.signal.name.toUpperCase()}',style: TextStyle(fontSize:20,fontWeight:FontWeight.bold,color:color)),Text('Rule score: ${a.score} (not probability)',style: const TextStyle(color:Colors.white60)),const Divider(height:24),for(final r in a.rationale) Padding(padding: const EdgeInsets.only(bottom:8),child: Text('• $r'))]))); }

  Widget _paperPage() => ListView(padding: const EdgeInsets.all(16), children: [const Text('PAPER TRADING',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),const SizedBox(height:8),_notice('Simulated orders only. Prices are manually entered and are not live exchange quotes.'),_field('Symbol',_symbol),_field('Entry / exit price (₹)',_price),_field('Quantity',_qty),Row(children:[Expanded(child:FilledButton(onPressed:()=>_paperTrade('BUY'),child:const Text('Paper BUY'))),const SizedBox(width:10),Expanded(child:FilledButton.tonal(onPressed:()=>_paperTrade('SELL'),child:const Text('Paper SELL')))]),const SizedBox(height:18),const Text('POSITIONS',style:TextStyle(fontWeight:FontWeight.bold)),const SizedBox(height:8),if(_broker.positions.isEmpty) const Text('No paper trades yet.',style:TextStyle(color:Colors.white60)),for(final p in _broker.positions) Card(child:ListTile(title:Text('${p.side} ${p.symbol} × ${p.quantity}'),subtitle:Text('Entry ₹${p.entryPrice.toStringAsFixed(2)}${p.isOpen?' • OPEN':' • Closed • P/L ₹${p.realisedPnl.toStringAsFixed(2)}'}'),trailing:p.isOpen?TextButton(onPressed:(){final px=double.tryParse(_price.text)??0;final ok=_broker.close(p.id,px);setState((){});if(!ok)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Enter a valid exit price.')));},child:const Text('Close')):null))]);

  Widget _settingsPage() => ListView(padding: const EdgeInsets.all(16), children: [const Text('SETTINGS & INTEGRATIONS',style:TextStyle(fontSize:18,fontWeight:FontWeight.bold)),const SizedBox(height:12),_integration('Zerodha Kite Connect','Planned • API credentials and authenticated market feed required'),_integration('KP Ephemeris provider','Not connected • Swiss Ephemeris / KP ayanamsa validation required'),_integration('Notifications','Planned • Signal and risk alerts'),_notice('Never place Zerodha API secrets inside the mobile app. A secure backend with OAuth/session handling is required before broker integration.'),const SizedBox(height:8),const Text('Default virtual capital: ₹1,00,000\nMode: Paper trading only\nLive order placement: Disabled',style:TextStyle(color:Colors.white70))]);

  Widget _integration(String title,String sub)=>Card(child:ListTile(leading:const Icon(Icons.link),title:Text(title),subtitle:Text(sub),isThreeLine:true,trailing:const Icon(Icons.lock_outline)));
  Widget _metric(String title,String value,IconData icon)=>Card(child:Padding(padding:const EdgeInsets.all(14),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Icon(icon,color:Colors.lightBlueAccent),const SizedBox(height:10),Text(value,style:const TextStyle(fontSize:22,fontWeight:FontWeight.bold)),Text(title,style:const TextStyle(color:Colors.white60,fontSize:12))])));
  Widget _notice(String text)=>Container(padding:const EdgeInsets.all(12),decoration:BoxDecoration(color:Colors.blueGrey.withOpacity(.18),borderRadius:BorderRadius.circular(12),border:Border.all(color:Colors.blueGrey.withOpacity(.35))),child:Text(text,style:const TextStyle(fontSize:12,color:Colors.white70)));
  Widget _field(String label,TextEditingController c,{String? hint})=>Padding(padding:const EdgeInsets.only(bottom:10),child:TextField(controller:c,decoration:InputDecoration(labelText:label,hintText:hint,border:const OutlineInputBorder(),isDense:true)));
}
