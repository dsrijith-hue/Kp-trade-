# KP Astro Trader — Android starter

Flutter starter for a KP astrology intraday analysis and paper-trading app.

## Included
- Android-ready Flutter project structure and dark dashboard UI.
- Manual Ascendant NL/RL/SL/SSL input.
- Transparent, weighted sample rule engine using supplied house significations.
- Paper positions with virtual capital and manual entry/exit prices.
- Zerodha and ephemeris integration placeholders.

## Important limitations
This is a functional UI/prototype scaffold, not a production trading system. It does not yet calculate a live Ascendant, planetary longitudes, KP star/sub/sub-sub divisions, cuspal significators, or fetch market quotes. It does not connect to Zerodha or place orders. The sample house scoring is a configurable illustrative rule, not a validated KP trading method or evidence of predictive performance. Do not use it to make real trades.

## Run
1. Install Flutter stable and Android Studio / Android SDK.
2. From this folder run `flutter pub get`.
3. Run `flutter run` on an Android emulator or device.
4. Build APK with `flutter build apk --release` after testing.

## Next engineering milestones
1. Confirm KP calculation conventions: ayanamsa, house system, node treatment, true/mean positions, and exact sub/sub-sub division algorithm.
2. Implement and validate the ephemeris service against a trusted KP reference for known timestamps and locations.
3. Add secure backend for market data and Kite Connect OAuth/session lifecycle. Keep API secrets off-device.
4. Add candle storage, paper execution assumptions (slippage, brokerage, taxes), risk limits, and backtesting.
5. Validate rule logic on out-of-sample historical data before considering any live trading capability.

## Suggested environment configuration
Do not commit credentials. Use server-side secret storage for broker credentials and environment-specific configuration for non-secret endpoints.

## Editable analysis timestamp
The KP Analysis screen includes editable date, hour/minute, and seconds. The selected local device timestamp is attached to each manual KP snapshot. Use the date picker for the calendar date, the time picker for hours/minutes, and the seconds field (00–59) for second-level precision. This currently timestamps the manually entered KP factors; it does not calculate planetary positions for that timestamp until an ephemeris/KP calculation provider is implemented.
